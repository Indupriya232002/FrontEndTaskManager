export class Task {
    taskID?: number
    taskName? :string 
    taskDescription?: string
    taskDate?: Date
    status  = "Not Completed";

}
