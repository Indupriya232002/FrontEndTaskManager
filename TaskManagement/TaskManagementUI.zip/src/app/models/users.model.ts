export class Users {
    userId? : number
    firstName? : string
    lastName?: string 
    email?: string
    password?: string
    phoneNum?: number
  
}
